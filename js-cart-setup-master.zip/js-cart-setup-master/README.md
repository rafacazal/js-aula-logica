
# Cart layout - Base

[![ForTheBadge built-with-love](http://ForTheBadge.com/images/badges/built-with-love.svg)](https://GitHub.com/Naereen/) [![forthebadge](https://forthebadge.com/images/badges/uses-js.svg)](https://forthebadge.com)

Esse projeto tem como finalidade pegar como estrutura base uma loja de cupcakes para a prática do exercício de lógica de programação com javascript da WoMakersCode - Lógica de Programação.

Use como base para começar o exercício.

Projeto clonado de [John Smilga](https://github.com/john-smilga/js-cart-setup)


